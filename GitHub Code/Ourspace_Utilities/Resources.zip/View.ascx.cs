/*
' Copyright (c) 2010  DotNetNuke Corporation
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

using System;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Services.Localization;
using DotNetNuke.Security;
using System.IO;
using System.Web;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Reflection;
using DotNetNuke.Common;
using System.Runtime.Serialization;
using System.Net;
using System.Text;
using System.Runtime.Serialization.Json;


namespace DotNetNuke.Modules.Ourspace_Utilities
{

    /// -----------------------------------------------------------------------------
    /// <summary>
    /// The ViewOurspace_Utilities class displays the content
    /// </summary>
    /// -----------------------------------------------------------------------------
    public partial class View : Ourspace_UtilitiesModuleBase, IActionable
    {
        String CONNECTION_STRING = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();


        #region Event Handlers
        override protected void OnInit(EventArgs e)
        {
            InitializeComponent();
            base.OnInit(e);
        }

        private void InitializeComponent()
        {
            this.Load += new System.EventHandler(this.Page_Load);
        }


        /// -----------------------------------------------------------------------------
        /// <summary>
        /// Page_Load runs when the control is loaded
        /// </summary>
        /// -----------------------------------------------------------------------------
        private void Page_Load(object sender, System.EventArgs e)
        {
            try
            {

            }
            catch (Exception exc) //Module failed to load
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        public string GetOurSpaceUserImgUrl(HttpServerUtility currentWebRequest, int userId)
        {
            // Checking if user is Facebook user
            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();
            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                string sql = "";
                string sqlCheck = string.Format(@"SELECT * FROM Ourspace_Forum_User_Info WHERE UserId ={0}", userId);
                using (SqlCommand cmdCheck = new SqlCommand(sqlCheck, sqlConn))
                {
                    string strPath = currentWebRequest.MapPath(".\\Portals\\" + PortalId + "\\Users\\" + userId.ToString("000") + "\\");

                    cmdCheck.CommandType = CommandType.Text;
                    SqlDataReader reader = cmdCheck.ExecuteReader();
                    if (reader.Read())
                    {

                        // Is facebook user
                        if (reader["facebookId"] != null && reader["facebookId"].ToString() != "" && reader["facebookId"].ToString() != "0")
                        {
                            strPath = "http://graph.facebook.com/" + reader["facebookId"].ToString() + "/picture";
                        }
                        else
                        {
                            if (Directory.Exists(strPath))
                            {
                                strPath = ConfigurationManager.AppSettings["OurspaceDomain"];
                                if (userId <= 9)
                                {
                                    strPath = ConfigurationManager.AppSettings["OurspaceDomain"];
                                    strPath += "/Portals/" + PortalId + "/Users/" + userId.ToString("000") + "/" + userId.ToString("00");
                                }
                                else
                                {
                                    strPath += "/Portals/" + PortalId + "/Users/" + userId.ToString("000") + "/" + userId;
                                }
                                strPath += "/" + userId + "/" + userId + "_50.jpg?" + DateTime.Now.Ticks;
                                return strPath;
                            }
                            else
                            {
                                strPath = ConfigurationManager.AppSettings["OurspaceDomain"];
                                strPath += "/images/no-avatar.png";
                            }
                        }


                        sqlConn.Close();
                        //strPath = Control.ResolveClientUrl("~/images/no-avatar.png");// ResolveUrl("~/images/no-avatar.png");
                        return strPath;


                    }
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();

                        sqlConn.Close();
                    }
                }
                //



            }
            return "";
        }

        public string GetHighResUserImgUrl(HttpServerUtility currentWebRequest, int userId)
        {
            // Checking if user is Facebook user
            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();
            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                string sql = "";
                string sqlCheck = string.Format(@"SELECT * FROM Ourspace_Forum_User_Info WHERE UserId ={0}", userId);
                using (SqlCommand cmdCheck = new SqlCommand(sqlCheck, sqlConn))
                {
                    string strPath = currentWebRequest.MapPath(".\\Portals\\" + PortalId + "\\Users\\" + userId.ToString("000") + "\\");

                    cmdCheck.CommandType = CommandType.Text;
                    SqlDataReader reader = cmdCheck.ExecuteReader();
                    if (reader.Read())
                    {

                        // Is facebook user
                        if (IsFacebookUser(userId))
                        {
                            strPath = "http://graph.facebook.com/" + reader["facebookId"].ToString() + "/picture?type=large";
                        }
                        else
                        {
                            if (Directory.Exists(strPath))
                            {
                                strPath = ConfigurationManager.AppSettings["OurspaceDomain"];
                                if (userId <= 9)
                                {
                                    strPath = ConfigurationManager.AppSettings["OurspaceDomain"];
                                    strPath += "/Portals/" + PortalId + "/Users/" + userId.ToString("000") + "/" + userId.ToString("00");
                                }
                                else
                                {
                                    strPath += "/Portals/" + PortalId + "/Users/" + userId.ToString("000") + "/" + userId;
                                }
                                strPath += "/" + userId + "/" + userId + "_180.jpg?" + DateTime.Now.Ticks;
                                return strPath;
                            }
                            else
                            {
                                strPath = ConfigurationManager.AppSettings["OurspaceDomain"];
                                strPath += "/images/no-avatar-high.png";
                            }
                        }


                        sqlConn.Close();
                        //strPath = Control.ResolveClientUrl("~/images/no-avatar.png");// ResolveUrl("~/images/no-avatar.png");
                        return strPath;


                    }
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();

                        sqlConn.Close();
                    }
                }
                //



            }
            return "";
        }

        public bool IsFacebookUser(int userId)
        {

            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();
            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                string sql = "";
                string sqlCheck = string.Format(@"SELECT * FROM Ourspace_Forum_User_Info WHERE UserId ={0}", userId);
                using (SqlCommand cmdCheck = new SqlCommand(sqlCheck, sqlConn))
                {
                    cmdCheck.CommandType = CommandType.Text;
                    SqlDataReader reader = cmdCheck.ExecuteReader();
                    if (reader.Read())
                    {

                        // Is facebook user
                        if (reader["facebookId"] != null && reader["facebookId"].ToString() != "" && reader["facebookId"].ToString() != "0")
                        {
                            sqlConn.Close();
                            return true;
                        }
                        else
                        {
                            sqlConn.Close();
                            return false;
                        }
                    }
                }
            }
            return false;
        }



        public int GetThreadId(int postId)
        {
            string sql = "";
            int threadId = -1;

            sql = string.Format(@"SELECT ThreadId FROM  Forum_Posts  WHERE  PostID = {0}", postId);

            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();

            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlDataReader reader = cmd.ExecuteReader();
                    int i = 0;
                    while (reader.Read())
                    {

                        threadId = int.Parse(reader["ThreadId"].ToString());

                    }
                }
            }
            return threadId;

        }

        public int GetForumId(int threadId)
        {
            string sql = "";
            int forumId = -1;

            sql = string.Format(@"SELECT ForumId FROM  Forum_Threads  WHERE  ThreadId = {0}", threadId);

            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();

            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlDataReader reader = cmd.ExecuteReader();
                    int i = 0;
                    while (reader.Read())
                    {

                        forumId = int.Parse(reader["ForumId"].ToString());

                    }
                }
            }
            return forumId;

        }

        public int GetPhaseId(int threadId)
        {
            string sql = "";
            int phaseId = -1;

            sql = string.Format(@"SELECT phaseId FROM  Ourspace_Forum_Thread_Info  WHERE  threadId = {0}", threadId);

            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();

            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlDataReader reader = cmd.ExecuteReader();
                    int i = 0;
                    while (reader.Read())
                    {

                        phaseId = int.Parse(reader["phaseId"].ToString());

                    }
                }
            }
            return phaseId;

        }

        public string GetThreadName(int postId)
        {
            string sql = "";
            string threadName = "";
            int threadId = -1;

            sql = string.Format(@"SELECT ThreadId FROM  Forum_Posts  WHERE  PostID = {0}", postId);

            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();

            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlDataReader reader = cmd.ExecuteReader();
                    int i = 0;
                    while (reader.Read())
                    {

                        threadId = int.Parse(reader["ThreadId"].ToString());

                    }
                }
            }
            sql = string.Format(@"SELECT Subject FROM  Forum_Posts  WHERE  ThreadId = {0} AND ParentPostId = 0", threadId);
            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlDataReader reader = cmd.ExecuteReader();
                    int i = 0;
                    while (reader.Read())
                    {

                        threadName = reader["Subject"].ToString();
                        break;
                    }
                }
            }

            return threadName;

        }

        public string GetTimeAgo(DateTime date)
        {
            if (DateTime.Compare(DateTime.Now, date) >= 0)
            {
                TimeSpan ts = DateTime.Now.Subtract(date);
                //return string.Format("{0} days, {1} hours, {2} minutes, {3} seconds",
                //  , ts.Hours, ts.Minutes, ts.Seconds);
                string pointsLbl = Localization.GetString("hours", LocalResourceFile);
                string test = Localization.GetString("hoursAgo", LocalResourceFile);
                string test2 = Localization.GetString("daysAgo", LocalResourceFile);
                string resource = ModulePath + LocalResourceFile + "View.ascx.resx";

                if (ts.Days < 1)
                {
                    return ts.Hours + "#hoursAgo.Text";
                }
                else
                {
                    string testing = ts.Days + "#daysAgo.Text";
                    return ts.Days + "#daysAgo.Text";
                }
                return ts.Days.ToString();
            }

            return "0";

        }

        public string GetUserProfileLink(int userId, string language, bool isFacebook)
        {
            int profileTab = 71;
            if (language == "en-GB")
            {
                profileTab = 71;
            }
            string profileLink = "";
            if (isFacebook)
            {
                Dictionary<string, int> tabs = new Dictionary<string, int>();
                tabs.Add("en-GB", 287);
                tabs.Add("el-GR", 288);
                tabs.Add("cs-CZ", 289);
                tabs.Add("de-AT", 290);
                profileTab = tabs[language];
                string[] parameters1 = new string[2];
                parameters1 = new string[2] { "user=" + userId, "facebook=1" };
                profileLink = DotNetNuke.Common.Globals.NavigateURL(profileTab, "", parameters1);
            }
            else
            {
                string[] parameters2 = new string[1];
                parameters2 = new string[1] { "user=" + userId };
                profileLink = DotNetNuke.Common.Globals.NavigateURL(profileTab, "", parameters2);
            }
            return profileLink;
        }

        public int GetUserPoints(int userId)
        {
            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();

            using (var sqlConn = new SqlConnection(connectionString))
            {
                String sql =
        @"SELECT [Ourspace_Forum_User_Info].[points] FROM [Ourspace_Forum_User_Info]
              INNER JOIN [Users] ON [Ourspace_Forum_User_Info].[UserID] = [Users].[UserID]
              WHERE  [Ourspace_Forum_User_Info].[points] IS NOT NULL AND [Users].[UserID] = " + userId;
                sqlConn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlDataReader reader = cmd.ExecuteReader();
                    int i = 0;
                    while (reader.Read())
                    {
                        int points = reader.GetInt32(0);
                        return points;
                    }
                    reader.Close();
                }
                sqlConn.Close();
            }
            return 0;

        }

        public int GetLevel(int points)
        {
            // Level 1 > 10 points
            // Level 2 > 80 points
            // Level 3 > 300 points
            // Level 4 > 600 points
            // Level 5 > 1000 points
            if (points > 1000)
                return 5;
            else if (points > 500)
                return 4;
            else if (points > 200)
                return 3;
            else if (points > 10)
                return 2;
            else
                return 1;
        }

        public string GetLevelName(int level, string localResourceFile)
        {
            string resource = this.LocalResourceFile;
            string level1 = Localization.GetString("level1Name", localResourceFile);
            string level12 = Localization.GetString("level1Name.Text", localResourceFile);
            return Localization.GetString("level" + level + "Name", localResourceFile);
        }

        public int GetPointsToNextLevel(int points)
        {
            int nextLevelPoints = 0;
            int currentLevel = GetLevel(points);

            switch (currentLevel)
            {
                case 1:
                    nextLevelPoints = 10;
                    break;
                case 2:
                    nextLevelPoints = 200;
                    break;
                case 3:
                    nextLevelPoints = 500;
                    break;
                case 4:
                    nextLevelPoints = 1000;
                    break;
                default:
                    return -1;
                    break;
            }

            return nextLevelPoints - points;
        }


        public List<string> GetImagesInHTMLString(string htmlString)
        {
            List<string> images = new List<string>();
            string pattern = @"<(img)\b[^>]*>";

            Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
            MatchCollection matches = rgx.Matches(htmlString);

            for (int i = 0, l = matches.Count; i < l; i++)
            {
                images.Add(matches[i].Value);
            }

            return images;
        }

        public string GetTrimmedBody(HttpServerUtility currentWebRequest, int length, string body)
        {
            //body = Server.UrlDecode(body);
            body = currentWebRequest.HtmlDecode(body);

            body = Regex.Replace(body, @"<[^>]*>", String.Empty);

            if (body.Length >= length)
            {
                return body.Substring(0, length - 10) + "...";
            }
            else
            {
                return body;
            }


        }

        public string GetPostUrl(int forumId, int postId)
        {
            string url;
            String[] urlParams = {"forumid=" + forumId.ToString(), 
                                   "postid=" + postId.ToString(), 
                                   "scope=posts"};
            url = Globals.NavigateURL(62, "", urlParams);
            url = url + "#" + postId.ToString();
            return url;
        }

        public string ReplaceQueryString(string url, string key, string value)
        {
            return Regex.Replace(
                url,
                @"([?&]" + key + ")=[^?&]+",
                "$1=" + value);
        }

        public void SendEmailToThreadTrackers(int threadId, int postId, string lang)
        {
            // The HTML template of the email that notifies the user that a post has been posted in a 
            // thread he has subscribed in
            string htmlTemplate = "Hi [FIRSTNAME],<br><br>Someone has posted a new message in a discussion you are following on Ourspace. Follow the link below to see the new post: <br><br>[URL]";
            string htmlTemplateDeAt = "Hallo [FIRSTNAME],<br><br>jemand hat bei einer Diskussion der du auf OurSpace folgst einen neuen Beitrag gepostet. Um direkt zum Beitrag zu gelangen, klicke auf den Link unterhalb: <br><br>[URL]";
            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();

            string subject = "OurSpace - New post";
            string subjectDeAt = "OurSpace - Neuer Beitrag";
            string url = "";
            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                string sql = "SELECT     Forum_TrackedThreads.ForumID, Forum_TrackedThreads.ThreadID, Forum_TrackedThreads.UserID, Forum_TrackedThreads.CreatedDate, Forum_TrackedThreads.ModuleID, Users.Email, Users.FirstName, UserProfile.PropertyValue as Language, UserProfile.PropertyDefinitionID FROM   Forum_TrackedThreads INNER JOIN  Users ON Forum_TrackedThreads.UserID = Users.UserID INNER JOIN  UserProfile ON Users.UserID = UserProfile.UserID WHERE     (UserProfile.PropertyDefinitionID = 40) AND (Forum_TrackedThreads.ThreadID = " + threadId + ")";
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlDataReader reader = cmd.ExecuteReader();
                    int i = 0;
                    List<string> emails = new List<string>();
                    // Adding the current users email to list prevents him from receiving a notification email
                    // when he posts his message
                    emails.Add(UserInfo.Email);
                    while (reader.Read())
                    {
                        string email = reader["Email"].ToString();
                        if (!emails.Contains(email))
                        {
                            int forumId = Convert.ToInt32(reader["ForumId"]);
                            string name = reader["FirstName"].ToString();
                            string language = reader["Language"].ToString();

                            Ourspace_Utilities.View util = new Ourspace_Utilities.View();
                            if (url == "")
                                url = util.GetPostUrl(forumId, postId);
                            //string lang = CultureInfo.CurrentCulture.ToString();

                            string emailMessage = "";
                            string finalSubject = "";
                            if (language == "en-GB")
                            {
                                emailMessage = htmlTemplate.Replace("[FIRSTNAME]", name).Replace("[URL]", url);
                                finalSubject = subject;
                            }
                            else if (language == "de-AT")
                            {
                                emailMessage = htmlTemplateDeAt.Replace("[FIRSTNAME]", name).Replace("[URL]", url);
                                finalSubject = subjectDeAt;
                            }
                            else
                            {
                                emailMessage = htmlTemplate.Replace("[FIRSTNAME]", name).Replace("[URL]", url);
                                finalSubject = subject;
                            }

                            try
                            {


                                //emailTask.EmailQueueTaskAdd("info@ep-ourspace.eu", "OurSpace", 0, emailMessage, emailMessage, finalSubject, PortalID, forumMail.QueuePriority, objConfig.ModuleID, forumMail.EnableFriendlyToName, forumMail.DistroCall, forumMail.DistroIsSproc, forumMail.DistroParams, Date.Now(), False, "")
                                //Ourspace_Utilities.View util = new Ourspace_Utilities.View();
                                util.AddEmailToQueue("info@ourspace.eu", email, finalSubject, emailMessage);

                                //DotNetNuke.Services.Mail.Mail.SendEmail("info@ep-ourspace.eu", email, finalSubject, emailMessage);
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                    reader.Close();
                }
                sqlConn.Close();
            }
        }

        public bool AddEmailToQueue(string from, string to, string subject, string emailHtml)
        {
            try
            {

                //string sql = "INSERT INTO Ourspace_ForumEmailQueue (From, To, Subject, EmailHtml, DateCreated) VALUES (@from ,@to, @subject, @emailHtml)";
                using (var sqlConn = new SqlConnection(CONNECTION_STRING))
                {
                    sqlConn.Open();
                    //string sql = "INSERT INTO Ourspace_Proposal_Solutions VALUES (@threadId,'',0,0,0,0,0,@postId,0)";
                    string sql = "INSERT INTO Ourspace_ForumEmailQueue ([From], [To], [Subject], [EmailHtml]) VALUES (@from ,@to, @subject, @emailHtml)";

                    using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.Add(new SqlParameter("@from", from));
                        cmd.Parameters.Add(new SqlParameter("@to", to));
                        cmd.Parameters.Add(new SqlParameter("@subject", subject));
                        cmd.Parameters.Add(new SqlParameter("@emailHtml", emailHtml));
                        int rows = cmd.ExecuteNonQuery();
                    }
                    sqlConn.Close();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public void UpdateThreadPhase(int threadId, int phaseId)
        {
            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();
            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                string sql = string.Format(@"UPDATE Ourspace_Forum_Thread_Info SET phaseId = {0} WHERE threadId = {1}", phaseId, threadId);
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                }
                sqlConn.Close();
            }
        }

        public void RejectThread(int rejectReasonId, string comment, int threadId)
        {
            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();
            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                string sql = string.Format(@"UPDATE Ourspace_Forum_Thread_Info SET rejectReasonId = @rejectReasonId, rejectComment = @rejectComment WHERE threadId = @threadId");
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.Parameters.Add(new SqlParameter("@rejectReasonId", rejectReasonId));
                    cmd.Parameters.Add(new SqlParameter("@rejectComment", comment));
                    cmd.Parameters.Add(new SqlParameter("@threadId", threadId));
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                }
                sqlConn.Close();
            }
        }

        public void SendEmailToThreadTrackersAboutTopicRejection(int threadId)
        {
            string threadName = GetThreadName(threadId);

            // The HTML template of the email that notifies the user that a post has been posted in a 
            // thread he has subscribed in
            string htmlTemplate = "Hi [FIRSTNAME],<br><br>The topic '[THREAD_NAME]' has been rejected.<br><br>You can find more information about why it has been rejected here:<br><br>[URL]";
            string htmlTemplateDeAt = "Hi [FIRSTNAME],<br><br>The topic '[THREAD_NAME]' has been rejected.<br><br>You can find more information about why it has been rejected here:<br><br>[URL]";

            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();

            string subject = "OurSpace - Topic Rejected";
            string subjectDeAt = "OurSpace - Topic Rejected";
            string url = "";
            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                string sql = "SELECT     Forum_TrackedThreads.ForumID, Forum_TrackedThreads.ThreadID, Forum_TrackedThreads.UserID, Forum_TrackedThreads.CreatedDate, Forum_TrackedThreads.ModuleID, Users.Email, Users.FirstName, UserProfile.PropertyValue as Language, UserProfile.PropertyDefinitionID FROM   Forum_TrackedThreads INNER JOIN  Users ON Forum_TrackedThreads.UserID = Users.UserID INNER JOIN  UserProfile ON Users.UserID = UserProfile.UserID WHERE     (UserProfile.PropertyDefinitionID = 40) AND (Forum_TrackedThreads.ThreadID = " + threadId + ")";
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlDataReader reader = cmd.ExecuteReader();
                    int i = 0;
                    List<string> emails = new List<string>();

                    while (reader.Read())
                    {
                        string email = reader["Email"].ToString();
                        if (!emails.Contains(email))
                        {
                            int forumId = Convert.ToInt32(reader["ForumId"]);
                            string name = reader["FirstName"].ToString();
                            string language = reader["Language"].ToString();

                            string emailMessage = "";
                            string finalSubject = "";
                            if (language == "en-GB")
                            {
                                url = "http://www.joinourspace.eu/tabid/73/threadid/" + threadId + "/language/" + language + "/scope/posts/Default.aspx";
                                emailMessage = htmlTemplate.Replace("[FIRSTNAME]", name).Replace("[URL]", url).Replace("[THREAD_NAME]", threadName);
                                finalSubject = subject;
                            }
                            else if (language == "de-AT")
                            {
                                url = "http://www.joinourspace.eu/tabid/73/threadid/" + threadId + "/language/" + language + "/scope/posts/Default.aspx";
                                emailMessage = htmlTemplateDeAt.Replace("[FIRSTNAME]", name).Replace("[URL]", url).Replace("[THREAD_NAME]", threadName);
                                finalSubject = subjectDeAt;
                            }
                            else
                            {
                                url = "http://www.joinourspace.eu/tabid/73/threadid/" + threadId + "/language/" + language + "/scope/posts/Default.aspx";
                                emailMessage = htmlTemplate.Replace("[FIRSTNAME]", name).Replace("[URL]", url).Replace("[THREAD_NAME]", threadName);
                                finalSubject = subject;
                            }

                            try
                            {
                                AddEmailToQueue("info@ourspace.eu", email, finalSubject, emailMessage);
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                    reader.Close();
                }
                sqlConn.Close();
            }
        }


        public void TransferThreadSubscriptionsToPhase2(int threadId, int newForumId)
        {

            using (var sqlConn = new SqlConnection(CONNECTION_STRING))
            {
                sqlConn.Open();
                string sql = "UPDATE     Forum_TrackedThreads SET ForumId = " + newForumId + ", ModuleId = 381 WHERE threadId = " + threadId + "";
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                }
                sqlConn.Close();
            }
        }


        public int GetUserLastPostId(int userId)
        {
            
            int postId = -1;
            using (var sqlConn = new SqlConnection(CONNECTION_STRING))
            {
                sqlConn.Open();
                string sql = "SELECT     PostID, UserID FROM         Forum_Posts WHERE UserID = " + userId + " ORDER BY postId desc";
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlDataReader reader = cmd.ExecuteReader();
                    int i = 0;
                    List<string> emails = new List<string>();

                    if (reader.Read())
                    {
                        postId = Convert.ToInt32( reader["PostId"].ToString());
                        
                    }
                    reader.Close();
                }
                sqlConn.Close();
                return postId;
            }
        }

        public void SendEmailToThreadTrackersAboutMovingToPhase2(int forumId, int threadId)
        {
            string threadName = GetThreadName(threadId);

            // The HTML template of the email that notifies the user that a post has been posted in a 
            // thread he has subscribed in
            string htmlTemplate = "Hi [FIRSTNAME],<br><br>The discussion '[THREAD_NAME]' has moved to the Discussion Phase.<br><br>You can find the discussion in its new phase and start posting yourself here:<br><br>[URL]";
            string htmlTemplateDeAt = "Hi [FIRSTNAME],<br><br>The discussion '[THREAD_NAME]' has moved to the Discussion Phase.<br><br>You can find the discussion in its new phase and start posting yourself here:<br><br>[URL]";

            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();

            string subject = "OurSpace - Topic moved to Discussion Phase";
            string subjectDeAt = "OurSpace - Topic moved to Discussion Phase";
            string url = "";
            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                string sql = "SELECT     Forum_TrackedThreads.ForumID, Forum_TrackedThreads.ThreadID, Forum_TrackedThreads.UserID, Forum_TrackedThreads.CreatedDate, Forum_TrackedThreads.ModuleID, Users.Email, Users.FirstName, UserProfile.PropertyValue as Language, UserProfile.PropertyDefinitionID FROM   Forum_TrackedThreads INNER JOIN  Users ON Forum_TrackedThreads.UserID = Users.UserID INNER JOIN  UserProfile ON Users.UserID = UserProfile.UserID WHERE     (UserProfile.PropertyDefinitionID = 40) AND (Forum_TrackedThreads.ThreadID = " + threadId + ")";
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlDataReader reader = cmd.ExecuteReader();
                    int i = 0;
                    List<string> emails = new List<string>();

                    while (reader.Read())
                    {
                        string email = reader["Email"].ToString();
                        if (!emails.Contains(email))
                        {
                            string name = reader["FirstName"].ToString();
                            string language = reader["Language"].ToString();

                            string emailMessage = "";
                            string finalSubject = "";
                       // http://localhost/ourspace/OpenDebates/tabid/62/forumid/37/threadid/99/scope/posts/language/en-GB/Default.aspx
                            if (language == "en-GB")
                            {
                                url = "http://www.joinourspace.eu/tabid/62/threadid/" + threadId + "/language/" + language + "/forumId/" + forumId + "/scope/posts/Default.aspx";
                                emailMessage = htmlTemplate.Replace("[FIRSTNAME]", name).Replace("[URL]", url).Replace("[THREAD_NAME]", threadName);
                                finalSubject = subject;
                            }
                            else if (language == "de-AT")
                            {
                                url = "http://www.joinourspace.eu/tabid/62/threadid/" + threadId + "/language/" + language + "/forumId/" + forumId + "/scope/posts/Default.aspx";
                                emailMessage = htmlTemplateDeAt.Replace("[FIRSTNAME]", name).Replace("[URL]", url).Replace("[THREAD_NAME]", threadName);
                                finalSubject = subjectDeAt;
                            }
                            else
                            {
                                url = "http://www.joinourspace.eu/tabid/62/threadid/" + threadId + "/language/" + language + "/forumId/" + forumId + "/scope/posts/Default.aspx";
                                emailMessage = htmlTemplate.Replace("[FIRSTNAME]", name).Replace("[URL]", url).Replace("[THREAD_NAME]", threadName);
                                finalSubject = subject;
                            }

                            try
                            {
                                AddEmailToQueue("info@ourspace.eu", email, finalSubject, emailMessage);
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                    reader.Close();
                }
                sqlConn.Close();
            }
        }

        public void SendEmailToThreadTrackersAboutMovingToPhase3(int threadId, int postId, string lang)
        {
            string threadName = GetThreadName(postId);

            // The HTML template of the email that notifies the user that a post has been posted in a 
            // thread he has subscribed in
            string htmlTemplate = "Hi [FIRSTNAME],<br><br>The discussion '[THREAD_NAME]' has moved to the Voting Phase.<br><br>You can find the discussion in its current phase here:<br><br>[URL]";
            string htmlTemplateDeAt = "Hi [FIRSTNAME],<br><br>The discussion '[THREAD_NAME]' has moved to the Voting Phase.<br><br>You can find the discussion in its current phase here:<br><br>[URL]";

            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();

            string subject = "OurSpace - Discussion moved to Voting Phase";
            string subjectDeAt = "OurSpace - Discussion moved to Voting Phase";
            string url = "";
            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                string sql = "SELECT     Forum_TrackedThreads.ForumID, Forum_TrackedThreads.ThreadID, Forum_TrackedThreads.UserID, Forum_TrackedThreads.CreatedDate, Forum_TrackedThreads.ModuleID, Users.Email, Users.FirstName, UserProfile.PropertyValue as Language, UserProfile.PropertyDefinitionID FROM   Forum_TrackedThreads INNER JOIN  Users ON Forum_TrackedThreads.UserID = Users.UserID INNER JOIN  UserProfile ON Users.UserID = UserProfile.UserID WHERE     (UserProfile.PropertyDefinitionID = 40) AND (Forum_TrackedThreads.ThreadID = " + threadId + ")";
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlDataReader reader = cmd.ExecuteReader();
                    int i = 0;
                    List<string> emails = new List<string>();
                    // Adding the current users email to list prevents him from receiving a notification email
                    // when he posts his message
                    //emails.Add(UserInfo.Email);
                    while (reader.Read())
                    {
                        string email = reader["Email"].ToString();
                        if (!emails.Contains(email))
                        {
                            int forumId = Convert.ToInt32(reader["ForumId"]);
                            string name = reader["FirstName"].ToString();
                            string language = reader["Language"].ToString();

                            string emailMessage = "";
                            string finalSubject = "";
                            if (language == "en-GB")
                            {
                                url = "http://www.joinourspace.eu/Solutionproposals/tabid/200/threadid/" + threadId + "/mode/featured/language/" + language + "/Default.aspx";
                                emailMessage = htmlTemplate.Replace("[FIRSTNAME]", name).Replace("[URL]", url).Replace("[THREAD_NAME]", threadName);
                                finalSubject = subject;
                            }
                            else if (language == "de-AT")
                            {
                                url = "http://www.joinourspace.eu/Solutionproposals/tabid/200/threadid/" + threadId + "/mode/featured/language/" + language + "/Default.aspx";
                                emailMessage = htmlTemplateDeAt.Replace("[FIRSTNAME]", name).Replace("[URL]", url).Replace("[THREAD_NAME]", threadName);
                                finalSubject = subjectDeAt;
                            }
                            else
                            {
                                url = "http://www.joinourspace.eu/Solutionproposals/tabid/200/threadid/" + threadId + "/mode/featured/language/" + language + "/Default.aspx";
                                emailMessage = htmlTemplate.Replace("[FIRSTNAME]", name).Replace("[URL]", url).Replace("[THREAD_NAME]", threadName);
                                finalSubject = subject;
                            }

                            try
                            {
AddEmailToQueue("info@ourspace.eu", email, finalSubject, emailMessage);
}
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                    reader.Close();
                }
                sqlConn.Close();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="threadId"></param>
        /// <param name="postId"></param>
        /// <returns>The url of the thread in its new phase</returns>
        public void SendEmailToThreadTrackersAboutMovingToPhase4(int threadId, int postId)
        {
            string threadName = GetThreadName(postId);

            // The HTML template of the email that notifies the user that a post has been posted in a 
            // thread he has subscribed in
            string htmlTemplate = "Hi [FIRSTNAME],<br><br>The discussion '[THREAD_NAME]' has moved to the Results Phase.<br><br>You can find the discussion in its current phase here:<br><br>[URL]";
            string htmlTemplateDeAt = "Hi [FIRSTNAME],<br><br>The discussion '[THREAD_NAME]' has moved to the Results Phase.<br><br>You can find the discussion in its current phase here:<br><br>[URL]";

            String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();

            string subject = "OurSpace - Discussion moved to Results Phase";
            string subjectDeAt = "OurSpace - Discussion moved to Results Phase";
            string url = "";
            using (var sqlConn = new SqlConnection(connectionString))
            {
                sqlConn.Open();
                string sql = "SELECT     Forum_TrackedThreads.ForumID, Forum_TrackedThreads.ThreadID, Forum_TrackedThreads.UserID, Forum_TrackedThreads.CreatedDate, Forum_TrackedThreads.ModuleID, Users.Email, Users.FirstName, UserProfile.PropertyValue as Language, UserProfile.PropertyDefinitionID FROM   Forum_TrackedThreads INNER JOIN  Users ON Forum_TrackedThreads.UserID = Users.UserID INNER JOIN  UserProfile ON Users.UserID = UserProfile.UserID WHERE     (UserProfile.PropertyDefinitionID = 40) AND (Forum_TrackedThreads.ThreadID = " + threadId + ")";
                using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlDataReader reader = cmd.ExecuteReader();
                    int i = 0;
                    List<string> emails = new List<string>();

                    while (reader.Read())
                    {
                        string email = reader["Email"].ToString();
                        if (!emails.Contains(email))
                        {
                            int forumId = Convert.ToInt32(reader["ForumId"]);
                            string name = reader["FirstName"].ToString();
                            string language = reader["Language"].ToString();

                            string emailMessage = "";
                            string finalSubject = "";
                            if (language == "en-GB")
                            {
                                url = "http://www.joinourspace.eu/tabid/196/result/" + threadId + "/language/" + language + "/Default.aspx";
                                emailMessage = htmlTemplate.Replace("[FIRSTNAME]", name).Replace("[URL]", url).Replace("[THREAD_NAME]", threadName);
                                finalSubject = subject;
                            }
                            else if (language == "de-AT")
                            {
                                url = "http://www.joinourspace.eu/tabid/196/result/" + threadId + "/language/" + language + "/Default.aspx";
                                emailMessage = htmlTemplateDeAt.Replace("[FIRSTNAME]", name).Replace("[URL]", url).Replace("[THREAD_NAME]", threadName);
                                finalSubject = subjectDeAt;
                            }
                            else
                            {
                                url = "http://www.joinourspace.eu/tabid/196/result/" + threadId + "/language/" + language + "/Default.aspx";
                                emailMessage = htmlTemplate.Replace("[FIRSTNAME]", name).Replace("[URL]", url).Replace("[THREAD_NAME]", threadName);
                                finalSubject = subject;
                            }

                            try
                            {
                                AddEmailToQueue("info@ourspace.eu", email, finalSubject, emailMessage);
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                    reader.Close();
                }
                sqlConn.Close();
            }
        }

        #endregion


        public void RefreshAccessToken()
        {
            
            AdmAuthentication admAuth = new AdmAuthentication("joinourspace_eu", "Y/usBFdwOtdOG8md/Ar7XpLW82PmWepVDeWtvHHyUj8=");
             AdmAccessToken admToken = admAuth.GetAccessToken();
             Application["BingTranslateAccessToken"] = admToken;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="from">en</param>
        /// <param name="to">el</param>
        /// <param name="accessToken"></param>
        /// <returns></returns>
        public string TranslateText(string from, string to, string text, string accessToken)
        {
            AdmAccessToken admToken = new AdmAccessToken();
            string headerValue;
            //Get Client Id and Client Secret from https://datamarket.azure.com/developer/applications/
            //Refer obtaining AccessToken (http://msdn.microsoft.com/en-us/library/hh454950.aspx) 
            
                // Create a header with the access_token property of the returned token
                //headerValue = "Bearer " + admToken.access_token;
              

            
            
           

            string uri = "http://api.microsofttranslator.com/v2/Http.svc/Translate?text=" + System.Web.HttpUtility.UrlEncode(text) + "&from=" + from + "&to=" + to;
            string authToken = "Bearer" + " " + admToken.access_token;

            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(uri);
            httpWebRequest.Headers.Add("Authorization", authToken);

            WebResponse response = null;


   response = httpWebRequest.GetResponse();
   using (Stream stream = response.GetResponseStream())
   {
     System.Runtime.Serialization.DataContractSerializer dcs = new System.Runtime.Serialization.DataContractSerializer(Type.GetType("System.String"));
     string translation = (string)dcs.ReadObject(stream);
     return translation;
     //Console.WriteLine("Translation for source text '{0}' from {1} to {2} is", text, "en", "de");
     //Console.WriteLine(translation);
   }

        }

        #region Bing translate
        [DataContract]
        public class AdmAccessToken
        {
            [DataMember]
            public string access_token { get; set; }
            [DataMember]
            public string token_type { get; set; }
            [DataMember]
            public string expires_in { get; set; }
            [DataMember]
            public string scope { get; set; }
        }

        public class AdmAuthentication
        {
            public static readonly string DatamarketAccessUri = "https://datamarket.accesscontrol.windows.net/v2/OAuth2-13";
            private string clientId;
            private string cientSecret;
            private string request;

            public AdmAuthentication(string clientId, string clientSecret)
            {
                this.clientId = clientId;
                this.cientSecret = clientSecret;
                //If clientid or client secret has special characters, encode before sending request
                this.request = string.Format("grant_type=client_credentials&client_id={0}&client_secret={1}&scope=http://api.microsofttranslator.com", HttpUtility.UrlEncode(clientId), HttpUtility.UrlEncode(clientSecret));
            }

            public AdmAccessToken GetAccessToken()
            {
                return HttpPost(DatamarketAccessUri, this.request);
            }

            private AdmAccessToken HttpPost(string DatamarketAccessUri, string requestDetails)
            {
                //Prepare OAuth request 
                WebRequest webRequest = WebRequest.Create(DatamarketAccessUri);
                webRequest.ContentType = "application/x-www-form-urlencoded";
                webRequest.Method = "POST";
                byte[] bytes = Encoding.ASCII.GetBytes(requestDetails);
                webRequest.ContentLength = bytes.Length;
                using (Stream outputStream = webRequest.GetRequestStream())
                {
                    outputStream.Write(bytes, 0, bytes.Length);
                }
                using (WebResponse webResponse = webRequest.GetResponse())
                {
                    DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(AdmAccessToken));
                    //Get deserialized object from JSON stream
                    AdmAccessToken token = (AdmAccessToken)serializer.ReadObject(webResponse.GetResponseStream());
                    return token;
                }
            }
        }

        #endregion


        #region Optional Interfaces

        public ModuleActionCollection ModuleActions
        {
            get
            {
                ModuleActionCollection Actions = new ModuleActionCollection();
                Actions.Add(GetNextActionID(), Localization.GetString("EditModule", this.LocalResourceFile), "", "", "", EditUrl(), false, SecurityAccessLevel.Edit, true, false);
                return Actions;
            }
        }

        #endregion

    }

}
