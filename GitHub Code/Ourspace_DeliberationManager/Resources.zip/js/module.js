﻿

$(document).ready(function () {
    // $('select#speedA').selectmenu();

    $('.ddlSortDebates').change(function (e) {

        //$('.debateSortLoading').removeClass('hidden');
    });


});