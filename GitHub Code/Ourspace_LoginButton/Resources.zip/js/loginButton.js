﻿
jQuery(document).ready(function () {
    jQuery('.logout-button-ourspace').attr('href', jQuery('.dnn-logout-button').attr('href'));

});