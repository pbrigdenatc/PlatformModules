﻿
jQuery(document).ready(function () {
    jQuery('.fb-friends-logout').attr('href', jQuery('#dnn_login_cmdLogin').attr('href'));





   

});
