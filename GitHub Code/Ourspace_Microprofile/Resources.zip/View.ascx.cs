/*
' Copyright (c) 2010  DotNetNuke Corporation
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

using System;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Services.Localization;
using DotNetNuke.Security;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using DotNetNuke.Modules.Ourspace_Utilities;
using System.Globalization;


namespace DotNetNuke.Modules.Ourspace_Microprofile
{

    /// -----------------------------------------------------------------------------
    /// <summary>
    /// The ViewOurspace_Microprofile class displays the content
    /// </summary>
    /// -----------------------------------------------------------------------------
    public partial class View : Ourspace_MicroprofileModuleBase, IActionable
    {

        #region Event Handlers

        override protected void OnInit(EventArgs e)
        {
            InitializeComponent();
            base.OnInit(e);
        }

        private void InitializeComponent()
        {
            this.Load += new System.EventHandler(this.Page_Load);
        }


        /// -----------------------------------------------------------------------------
        /// <summary>
        /// Page_Load runs when the control is loaded
        /// </summary>
        /// -----------------------------------------------------------------------------
        private void Page_Load(object sender, System.EventArgs e)
        {
            try
            {
                try
                {
                    string currentCookieCulture = "no cookie found";
                    string currentCulture = CultureInfo.CurrentCulture.Name;
                    if (Request.Cookies["language"] != null)
                    {
                        currentCookieCulture = Request.Cookies["language"].Value;
                    }
                    string test = UserInfo.Profile.GetPropertyValue("PreferredLocale");

                    lblCulture.Text = currentCulture;
                    lblCookie.Text = currentCookieCulture;
                    lblLangSetting.Text = test;
                }
                catch (Exception ex) { string exception = ex.Message; }

                if (UserId > -1)
                {
                    int profilePageTabId = 71;
                    if (CultureInfo.CurrentCulture.Name == "el-GR")
                {
                    profilePageTabId = 91;
                }
                else if (CultureInfo.CurrentCulture.Name == "cs-CZ")
                {
                    profilePageTabId = 104;
                }
                else if (CultureInfo.CurrentCulture.Name == "de-AT")
                {
                    profilePageTabId = 174;
                }

                    hprlnk_toProfile.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(profilePageTabId);
                

                    lblName.Text = UserInfo.FirstName;
                    lbl_FacebookId.Text = AuthenticateUser().ToString();

                    // This is the only place that FacebookuserId can be defined
                    Session["FacebookUserId"] = lbl_FacebookId.Text;

                    Ourspace_Utilities.View util = new Ourspace_Utilities.View();

                    img_Profile.ImageUrl = util.GetOurSpaceUserImgUrl(Server, UserId);

                    //if (Request.QueryString["language"] != null)
                    //{
                    //    string language = Request.QueryString["language"];
                    //    if (language == "en-GB" || language == "el-GR" || language == "cs-CZ" || language == "de-AT")
                    //    {
                    //        if (language != UserInfo.Profile.PreferredLocale)
                    //        {
                    //            UserInfo.Profile.SetProfileProperty("PreferredLocale", language);
                    //            DotNetNuke.Entities.Users.UserController.UpdateUser(0, UserInfo);
                    //        }

                    //    }
                    //}


                }
                else
                {
                   
                        ContainerControl.Visible = false;
                    
                }

                lblLanguage.Text = CultureInfo.CurrentUICulture.Name;
            }
            catch (Exception exc) //Module failed to load
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        #endregion

        #region Optional Interfaces

        public ModuleActionCollection ModuleActions
        {
            get
            {
                ModuleActionCollection Actions = new ModuleActionCollection();
                Actions.Add(GetNextActionID(), Localization.GetString("EditModule", this.LocalResourceFile), "", "", "", EditUrl(), false, SecurityAccessLevel.Edit, true, false);
                return Actions;
            }
        }

        #endregion

        public long AuthenticateUser()
        {
           
            string username = UserInfo.Username;
            string[] parts = username.Split('_');
            int length = parts.Length;
            string possibleFacebookId = parts[length - 1];
            long facebookId = 0;
            bool isInt = long.TryParse(possibleFacebookId, out facebookId);


                String connectionString = ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString();

           
                // edw elegxeis an to facebookId tairiazei me to facebookId pou
                // pires kalwntas to graph.api ktl

                // an tairiazoun simainei oti vrikes ton xristi stin vasi opote prostheteis to facebookId ston pinaka
                // forum_user_info, vazeis kai to access_token sto sessionToken ston idio pinaka.
                //  ;// userId


                using (var sqlConn = new SqlConnection(connectionString))
                {
                    sqlConn.Open();
                    string sql = "";
                    string sqlCheck = string.Format(@"SELECT * FROM Ourspace_Forum_User_Info WHERE UserId ={0}", UserId);
                    using (SqlCommand cmdCheck = new SqlCommand(sqlCheck, sqlConn))
                    {
                        cmdCheck.CommandType = CommandType.Text;
                        SqlDataReader reader = cmdCheck.ExecuteReader();
                        if (reader.HasRows)
                        {
                            sql = string.Format(@"UPDATE Ourspace_Forum_User_Info SET facebookId = {0} WHERE userId = {1}", facebookId, UserId);

                        }
                        else
                        {
                            sql = string.Format(@"INSERT INTO Ourspace_Forum_User_Info VALUES ({0},{1},{2},{3},{4},{5},{6},{7},'{8}',{9})", UserId, PortalId, 0, 0, 0, 0, 0, "''", DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss"), facebookId);

                        }

                        sqlConn.Close();
                    }
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, sqlConn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();

                        sqlConn.Close();
                    }
                    // reader.Close();
                }
            //}
            return facebookId;
        }
    }

}
