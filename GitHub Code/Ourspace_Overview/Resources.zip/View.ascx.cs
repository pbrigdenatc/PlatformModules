/*
' Copyright (c) 2010  DotNetNuke Corporation
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

using System;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Services.Localization;
using DotNetNuke.Security;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Telerik.Web.UI;


namespace DotNetNuke.Modules.Ourspace_Overview
{

    /// -----------------------------------------------------------------------------
    /// <summary>
    /// The ViewOurspace_Overview class displays the content
    /// </summary>
    /// -----------------------------------------------------------------------------
    public partial class View : Ourspace_OverviewModuleBase, IActionable
    {

        #region Event Handlers
        bool isFacebook = false;
        override protected void OnInit(EventArgs e)
        {
            InitializeComponent();
            base.OnInit(e);
        }

        private void InitializeComponent()
        {
            this.Load += new System.EventHandler(this.Page_Load);
        }


        /// -----------------------------------------------------------------------------
        /// <summary>
        /// Page_Load runs when the control is loaded
        /// </summary>
        /// -----------------------------------------------------------------------------
        private void Page_Load(object sender, System.EventArgs e)
        {
            try
            {
                Page.ClientScript.RegisterClientScriptInclude("overview.js", this.TemplateSourceDirectory + "/js/overview.js");
                if (Session["Ourspace_Overview_CurrentTab"] == null)
                {
                    Session["Ourspace_Overview_CurrentTab"] = "National";
                }
                if (Request.QueryString["facebook"] != null)
                {
                    isFacebook = true;
                }


                // lblOurspace_Overview_CurrentTab.Text = Session["Ourspace_Overview_CurrentTab"].ToString();
                if (Session["Ourspace_Overview_CurrentTab"] == "Eu")
                {
                    pnlEu.Visible = true;
                    pnlNational.Visible = false;

                    lnkbtnNationalDebates.CssClass = "tab-inactive";
                    lnkbtnEuDebates.CssClass = "tab-active";

                }
                else
                {
                    pnlEu.Visible = false;
                    pnlNational.Visible = true;

                    lnkbtnNationalDebates.CssClass = "tab-active";
                    lnkbtnEuDebates.CssClass = "tab-inactive";
                }

                if (Session["Ourspace_Overview_LanguageFilter"] != null)
                {
                    // lblOurspace_Overview_LanguageFilter.Text = Session["Ourspace_Overview_LanguageFilter"].ToString();
                    if (Session["Ourspace_Overview_LanguageFilter"] == "en-EU")
                    {
                        hdnfldLanguage.Value = Session["Ourspace_Overview_LanguageFilter"].ToString();
                        lstvw_OverviewItems.DataSourceID = sqldtsrc_ActiveDiscussionsPerLanguage.ID;
                        sqldtsrc_ActiveDiscussionsPerLanguage.DataBind();
                        lstvw_OverviewItems.DataBind();
                    }
                    else if (Session["Ourspace_Overview_LanguageFilter"] == "all")
                    {
                        lstvw_OverviewItems.DataSourceID = sqldtsrc_ActiveDiscussions.ID;
                        sqldtsrc_ActiveDiscussions.DataBind();
                        lstvw_OverviewItems.DataBind();

                        pnlViewingAll.Visible = true;
                        pnlViewingNational.Visible = false;
                    }
                    else
                    {
                        hdnfldLanguage.Value = Session["Ourspace_Overview_LanguageFilter"].ToString();
                        lstvw_OverviewItems.DataSourceID = sqldtsrc_ActiveDiscussionsPerLanguage.ID;
                        sqldtsrc_ActiveDiscussionsPerLanguage.DataBind();
                        lstvw_OverviewItems.DataBind();
                        pnlViewingAll.Visible = false;
                        pnlViewingNational.Visible = true;
                    }

                }
                else
                {
                    // hdnfldLanguage.Value = CultureInfo.CurrentCulture.Name;
                    lstvw_OverviewItems.DataSourceID = sqldtsrc_ActiveDiscussions.ID;
                    sqldtsrc_ActiveDiscussions.DataBind();
                    lstvw_OverviewItems.DataBind();

                    pnlViewingAll.Visible = true;
                    pnlViewingNational.Visible = false;

                }

        

            }
            catch (Exception exc) //Module failed to load
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void lstvw_OverviewItems_ItemDataBound(object sender, System.Web.UI.WebControls.ListViewItemEventArgs e)
        {
            // Localize previous/next buttons

            try{
            Label ThreadIDLabel = (Label)e.Item.FindControl("ThreadIDLabel");
            Label lbl_Body = (Label)e.Item.FindControl("lbl_Body");
            Label CreatedDateLabel = (Label)e.Item.FindControl("CreatedDateLabel");


            Label lblUserId = (Label)e.Item.FindControl("lblUserId");

            Literal ltrlImage = (Literal)e.Item.FindControl("ltrlImage");
            HyperLink hprlnk_subject = (HyperLink)e.Item.FindControl("hprlnk_subject");


            HyperLink hprlnk_userProfile = (HyperLink)e.Item.FindControl("hprlnk_userProfile");

            string[] dateArr = CreatedDateLabel.Text.Split(' ');
            if (dateArr.Length > 1)
            {
                CreatedDateLabel.Text = dateArr[0] + ", " + dateArr[1];
            }
            else
            {
                CreatedDateLabel.Text = dateArr[0];
            }


            string[] parameters2 = new string[2];
            parameters2 = new string[2] { "threadid=" + ThreadIDLabel.Text, "mode=featured" };
            string url = DotNetNuke.Common.Globals.NavigateURL(200, "", parameters2);
            hprlnk_subject.NavigateUrl = url;

            Ourspace_Utilities.View util = new Ourspace_Utilities.View();
            string lang = CultureInfo.CurrentCulture.ToString();
            hprlnk_userProfile.NavigateUrl = util.GetUserProfileLink(int.Parse(lblUserId.Text), lang, isFacebook);

            HtmlGenericControl phase1 = (HtmlGenericControl)e.Item.FindControl("phase1");
            HtmlGenericControl phase2 = (HtmlGenericControl)e.Item.FindControl("phase2");
            HtmlGenericControl phase3 = (HtmlGenericControl)e.Item.FindControl("phase3");
            HtmlGenericControl phase4 = (HtmlGenericControl)e.Item.FindControl("phase4");
            HtmlGenericControl[] phases = { phase1, phase2, phase3, phase4 };
            Label lblPhaseId = (Label)e.Item.FindControl("lblPhaseId");
            int currentPhase = int.Parse(lblPhaseId.Text);
            int i = 0;
            int j = 0;
            for (i = 0; i < currentPhase - 1; i++)
            {
                phases[i].Attributes["class"] = "phase-progress-icon phase-progress-complete phase-progress-" + (i + 1);

            }


            phases[i].Attributes["class"] = "phase-progress-icon phase-progress-active phase-progress-" + (i + 1);

            if (i == 3)
                phases[i].Attributes["class"] = "phase-progress-icon phase-progress-complete phase-progress-" + (i + 1);


            i++;
            for (j = i; j < 4; j++)
            {
                phases[j].Attributes["class"] = "phase-progress-icon phase-progress-inactive phase-progress-" + (i + 1);
            }


            // Make phase label links redirect user to phase according to phase.
            HyperLink hprlnk_Phase1 = (HyperLink)e.Item.FindControl("hprlnk_Phase1");
            HyperLink hprlnk_Phase2 = (HyperLink)e.Item.FindControl("hprlnk_Phase2");
            HyperLink hprlnk_Phase3 = (HyperLink)e.Item.FindControl("hprlnk_Phase3");
            HyperLink hprlnk_Phase4 = (HyperLink)e.Item.FindControl("hprlnk_Phase4");

            // Associating the Facebook tabs to each language

            // Suggest
            Dictionary<string, int> suggestTabs = new Dictionary<string, int>();
            suggestTabs.Add("en-GB", 271);
            suggestTabs.Add("el-GR", 272);
            suggestTabs.Add("cs-CZ", 273);
            suggestTabs.Add("de-AT", 274);

            // Join
            Dictionary<string, int> joinTabs = new Dictionary<string, int>();
            joinTabs.Add("en-GB", 259);
            joinTabs.Add("el-GR", 260);
            joinTabs.Add("cs-CZ", 261);
            joinTabs.Add("de-AT", 262);

            // Vote
            Dictionary<string, int> voteTabs = new Dictionary<string, int>();
            voteTabs.Add("en-GB", 279);
            voteTabs.Add("el-GR", 280);
            voteTabs.Add("cs-CZ", 281);
            voteTabs.Add("de-AT", 282);

            // Results


            // Subject link redirects user according to topic phase
            string language = CultureInfo.CurrentCulture.Name;
            if (currentPhase == 1)
            {
                if (isFacebook)
                {
                    int suggestTab = suggestTabs[language];
                    string[] parameters = new string[3];
                    //parameters1 = new string[2] { "user=" + userId, "facebook=1" };
                    parameters = new string[3] { "threadid=" + ThreadIDLabel.Text, "scope=posts", "facebook=1" };
                    hprlnk_subject.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(suggestTab, "", parameters);



                    // Phase links
                    hprlnk_Phase1.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(suggestTab, "", parameters);
                    hprlnk_Phase2.CssClass = "phase-unavailable";
                    hprlnk_Phase3.CssClass = "phase-unavailable";
                    hprlnk_Phase4.CssClass = "phase-unavailable";
                }
                else
                {
                    string[] parameters = new string[2];
                    parameters = new string[2] { "threadid=" + ThreadIDLabel.Text, "scope=posts" };
                    hprlnk_subject.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(73, "", parameters);


                    // Phase links
                    hprlnk_Phase1.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(73, "", parameters);
                    hprlnk_Phase2.CssClass = "phase-unavailable";
                    hprlnk_Phase3.CssClass = "phase-unavailable";
                    hprlnk_Phase4.CssClass = "phase-unavailable";
                }

            }
            else if (currentPhase == 2)
            {
                if (isFacebook)
                {
                    
                    int joinTab = joinTabs[language];
                    string[] parameters = new string[3];
                    parameters = new string[3] { "threadid=" + ThreadIDLabel.Text, "scope=posts", "facebook=1" };
                    hprlnk_subject.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(joinTab, "", parameters);

                    // Phase links                    
                    // Phase 2
                    hprlnk_Phase2.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(joinTab, "", parameters);
                    // Phase 1
                    hprlnk_Phase1.CssClass = "phase-unavailable";
                    //int suggestTab = suggestTabs[language];
                    //parameters = new string[3] { "threadid=" + ThreadIDLabel.Text, "scope=posts", "facebook=1" };
                   // hprlnk_Phase1.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(suggestTab, "", parameters);
                    // Phase 3
                    hprlnk_Phase3.CssClass = "phase-unavailable";
                    // Phase 4
                    hprlnk_Phase4.CssClass = "phase-unavailable";

                }
                else
                {
                    string[] parameters = new string[2];
                    parameters = new string[2] { "threadid=" + ThreadIDLabel.Text, "scope=posts" };
                    hprlnk_subject.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(62, "", parameters);
                    
                    // Phase links

                    // Phase 2
                    hprlnk_Phase2.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(62, "", parameters);
                    // Phase 1
                   // int suggestTab = suggestTabs[language];
                   // string[] phase1Parameters = new string[2];
                   // phase1Parameters = new string[2] { "threadid=" + ThreadIDLabel.Text, "scope=posts" };
                    //hprlnk_Phase1.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(73, "", phase1Parameters);
                    hprlnk_Phase1.CssClass = "phase-unavailable";
                    
                    // Phase 3
                    hprlnk_Phase3.CssClass = "phase-unavailable";
                    // Phase 4
                    hprlnk_Phase4.CssClass = "phase-unavailable";

                }

            }
            else if (currentPhase == 3)
            {
                if (isFacebook)
                {
                    int voteTab = voteTabs[language];
                    string[] parameters = new string[3];
                    parameters = new string[3] { "threadid=" + ThreadIDLabel.Text, "mode=featured", "facebook=1" };
                    hprlnk_subject.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(voteTab, "", parameters);

                    // Phase links

                    // Phase 3
                    hprlnk_Phase3.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(voteTab, "", parameters);
                    // Phase 1
                    //int suggestTab = suggestTabs[language];
                    //parameters = new string[3] { "threadid=" + ThreadIDLabel.Text, "scope=posts", "facebook=1" };
                    //hprlnk_Phase1.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(suggestTab, "", parameters);
                    hprlnk_Phase1.CssClass = "phase-unavailable";
                    // Phase 2
                    int joinTab = joinTabs[language];
                    parameters = new string[2] { "threadid=" + ThreadIDLabel.Text, "scope=posts" };
                    hprlnk_Phase2.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(joinTab, "", parameters);
                    // Phase 4
                    hprlnk_Phase4.CssClass = "phase-unavailable";

                }
                else
                {
                    string[] parameters = new string[2];
                    parameters = new string[2] { "threadid=" + ThreadIDLabel.Text, "mode=featured" };
                    hprlnk_subject.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(200, "", parameters);



                    // Phase links

                    // Phase 3
                    hprlnk_Phase3.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(200, "", parameters);
                    // Phase 1
                   // string[] phase1Parameters = new string[2];
                    //phase1Parameters = new string[2] { "threadid=" + ThreadIDLabel.Text, "scope=posts" };
                    //hprlnk_Phase1.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(73, "", phase1Parameters);
                    hprlnk_Phase1.CssClass = "phase-unavailable";
                    
                    // Phase 2
                    string[] phase2Parameters = new string[2];
                    phase2Parameters = new string[2] { "threadid=" + ThreadIDLabel.Text, "scope=posts" };
                    hprlnk_Phase2.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(62, "", phase2Parameters);
                    // Phase 4
                    hprlnk_Phase4.CssClass = "phase-unavailable";


                }
            }
            else if (currentPhase == 4)
            {
                if (isFacebook)
                {
                    int voteTab = voteTabs[language];
                    string[] parameters = new string[2];
                    parameters = new string[2] { "result=" + ThreadIDLabel.Text, "facebook=1" };
                    hprlnk_subject.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(voteTab, "", parameters);

                    // Phase links

                    // Phase 4
                    hprlnk_Phase4.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(voteTab, "", parameters);

                    // Phase 1
                    //int suggestTab = suggestTabs[language];
                    //parameters = new string[3] { "threadid=" + ThreadIDLabel.Text, "scope=posts", "facebook=1" };
                    //hprlnk_Phase1.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(suggestTab, "", parameters);
                    hprlnk_Phase1.CssClass = "phase-unavailable";

                    // Phase 2
                    int joinTab = joinTabs[language];
                    parameters = new string[2] { "threadid=" + ThreadIDLabel.Text, "scope=posts" };
                    hprlnk_Phase2.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(joinTab, "", parameters);

                    // Phase 3
                    //string[] voteParameters = new string[3];
                    //voteParameters = new string[3] { "threadid=" + ThreadIDLabel.Text, "mode=featured", "facebook=1" };
                    //hprlnk_Phase3.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(voteTab, "", voteParameters);
                    hprlnk_Phase3.CssClass = "phase-unavailable";
                }
                else
                {
                    string[] parameters = new string[1];
                    parameters = new string[1] { "result=" + ThreadIDLabel.Text };
                    hprlnk_subject.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(196, "", parameters);

                    hprlnk_Phase1.CssClass = "phase-unavailable";
                    // Phase links

                    // Phase 4
                    hprlnk_Phase4.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(196, "", parameters);

                    // Phase 2
                    string[] phase2Parameters = new string[2];
                    phase2Parameters = new string[2] { "threadid=" + ThreadIDLabel.Text, "scope=posts" };
                    hprlnk_Phase2.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(62, "", phase2Parameters);

                    // Phase 3
                    //string[] phase3Parameters = new string[2];
                    //phase3Parameters = new string[2] { "threadid=" + ThreadIDLabel.Text, "mode=featured" };
                    //hprlnk_Phase3.NavigateUrl = DotNetNuke.Common.Globals.NavigateURL(200, "", phase3Parameters);
                    hprlnk_Phase3.CssClass = "phase-unavailable";
                }

            }
                
            }catch(Exception ex)
            {
                string message = ex.Message;
                }
        }

        #endregion

        #region Optional Interfaces

        public ModuleActionCollection ModuleActions
        {
            get
            {
                ModuleActionCollection Actions = new ModuleActionCollection();
                Actions.Add(GetNextActionID(), Localization.GetString("EditModule", this.LocalResourceFile), "", "", "", EditUrl(), false, SecurityAccessLevel.Edit, true, false);
                return Actions;
            }
        }

        #endregion

        protected void lnkbtnNationalDebates_Click(object sender, EventArgs e)
        {
            lnkbtnNationalDebates.CssClass = "tab-active";
            lnkbtnEuDebates.CssClass = "tab-inactive";
            if (Session["Ourspace_Overview_NationalStatusAll"] != null)
            {
                if ((bool)Session["Ourspace_Overview_NationalStatusAll"])
                {
                    Session["Ourspace_Overview_LanguageFilter"] = "all";
                    hdnfldLanguage.Value = CultureInfo.CurrentCulture.Name;
                    lstvw_OverviewItems.DataSourceID = sqldtsrc_ActiveDiscussions.ID;
                    pnlViewingAll.Visible = true;
                    pnlViewingNational.Visible = false;
                }
                else
                {
                    Session["Ourspace_Overview_LanguageFilter"] = CultureInfo.CurrentCulture.Name;
                    hdnfldLanguage.Value = CultureInfo.CurrentCulture.Name;
                    lstvw_OverviewItems.DataSourceID = sqldtsrc_ActiveDiscussionsPerLanguage.ID;
                    pnlViewingAll.Visible = false;
                    pnlViewingNational.Visible = true;
                }
            }
            else
            {
                Session["Ourspace_Overview_LanguageFilter"] = CultureInfo.CurrentCulture.Name;
                hdnfldLanguage.Value = CultureInfo.CurrentCulture.Name;
                lstvw_OverviewItems.DataSourceID = sqldtsrc_ActiveDiscussionsPerLanguage.ID;
                pnlViewingAll.Visible = false;
                pnlViewingNational.Visible = true;
            }


            sqldtsrc_ActiveDiscussionsPerLanguage.DataBind();
            lstvw_OverviewItems.DataBind();



            pnlEu.Visible = false;
            pnlNational.Visible = true;

            Session["Ourspace_Overview_CurrentTab"] = "National";

        }

        protected void lnkbtnEuDebates_Click(object sender, EventArgs e)
        {
            lnkbtnNationalDebates.CssClass = "tab-inactive";
            lnkbtnEuDebates.CssClass = "tab-active";

            Session["Ourspace_Overview_LanguageFilter"] = "en-EU";
            hdnfldLanguage.Value = "en-EU";
            lstvw_OverviewItems.DataSourceID = sqldtsrc_ActiveDiscussionsPerLanguage.ID;
            sqldtsrc_ActiveDiscussionsPerLanguage.DataBind();
            lstvw_OverviewItems.DataBind();
            pnlEu.Visible = true;
            pnlNational.Visible = false;


            Session["Ourspace_Overview_CurrentTab"] = "Eu";

        }

        protected void lnkbtnViewAllLanguages_Click(object sender, EventArgs e)
        {
            Session["Ourspace_Overview_LanguageFilter"] = "all";
            Session["Ourspace_Overview_NationalStatusAll"] = true;
            lstvw_OverviewItems.DataSourceID = sqldtsrc_ActiveDiscussions.ID;
            sqldtsrc_ActiveDiscussions.DataBind();
            lstvw_OverviewItems.DataBind();
            pnlViewingAll.Visible = true;
            pnlViewingNational.Visible = false;
        }

        protected void lnkbtnViewOwnLanguage_Click(object sender, EventArgs e)
        {
            Session["Ourspace_Overview_LanguageFilter"] = CultureInfo.CurrentCulture.Name;
            Session["Ourspace_Overview_NationalStatusAll"] = false;
            hdnfldLanguage.Value = CultureInfo.CurrentCulture.Name;
            lstvw_OverviewItems.DataSourceID = sqldtsrc_ActiveDiscussionsPerLanguage.ID;
            sqldtsrc_ActiveDiscussionsPerLanguage.DataBind();
            lstvw_OverviewItems.DataBind();
            pnlViewingAll.Visible = false;
            pnlViewingNational.Visible = true;

        }

        public string GetString()
        {
            return Localization.GetString("Next");
        }

        protected void lstvw_OverviewItems_DataBound(object sender, EventArgs e)
        {
            //DataPager DataPager1 = (DataPager)lstvw_OverviewItems.FindControl("DataPager1");
            // ((NextPreviousPagerField)DataPager1.Fields[0]).NextPageText = "next story";
            // DataPager1.
            //int test = lstvw_OverviewItems.Items.Count; 


        }





    }

}
