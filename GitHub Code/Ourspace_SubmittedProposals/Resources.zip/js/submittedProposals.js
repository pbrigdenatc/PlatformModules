﻿jQuery(document).ready(function () {

    // Adding create proposal button to top of right sidebar
    var replyUrl = jQuery('.replyButton').first().attr('href');
    //jQuery('#dnn_sidebar2').prepend('<div class="submit-proposal-btn-wrapper"><a class="action-button fright" href="' + replyUrl + '">Submit Proposal</a><div class="cleared"></div></div>');
    jQuery('#dnn_sidebar2').prepend('<div class="submit-proposal-btn-wrapper"><span class="action-button fright">Submit Proposal</span><div class="cleared"></div></div>');

    // Moving Forum breadcrumb to bottom of page


   // jQuery('.main-bottom').html(jQuery('.Forum_BreadCrumb_Top_Wrapper').html());
})

